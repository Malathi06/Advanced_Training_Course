public class StringReverse {
public static void main(String[] args) {
	String str= "JAVA is Simple";
	System.out.println(str.toUpperCase());
	System.out.println(str.toLowerCase());
	
	String[] result = str.split(" ");

    for (String str1 : result) {
      System.out.print(str1.charAt(0)+" ");
      
    }
   System.out.println();
   
   String[] words1=str.split("\\s"); // Change order 
	for(String w:words1){  
		System.out.println(w); 
	}
    String reverseWord=""; 
    String words[]=str.split("\\s");  
    for(String w:words){  
        StringBuilder sb=new StringBuilder(w);  
        sb.reverse();  
        reverseWord+=sb.toString()+" ";  
    }  
    System.out.println(reverseWord.trim());  
    int count = 0;  
    
    //Counts each character except space  
    for(int i = 0; i < str.length(); i++) {  
        if(str.charAt(i) != ' ')  
            count++;  
    }  
      
    //Displays the total number of characters present in the given string  
    System.out.println("Total length is: " + count);  
   
}
}